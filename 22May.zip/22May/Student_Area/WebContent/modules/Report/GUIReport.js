﻿angular.module("GUIReport", []).controller("GUIReportCtrl", ["$scope","$http","$sce", "config",function ($scope,$http, $sce, config) {
	$scope.frameUrl = $sce.trustAsResourceUrl('https://webchat.botframework.com/embed/mybotchat_CY8wUEEc7qo?s=SCzEInF7O5I.cwA.reQ.bJuv5s2Z0Chr2p_kpm0wtGF5ac4puytoBr7EfXIhERg');
	
	/*Highcharts.chart('container1', {
	    chart: {	        type: 'column',
	        options3d: {	            enabled: true,	            alpha: 10,	            beta: 25, depth: 70}
	    },
	    title: {	        text: 'Student Monthly Report'	    },
	    plotOptions: {	        column: {	            depth: 25	        }	    },
	    xAxis: {	        categories: Highcharts.getOptions().lang.shortMonths	    },
	    yAxis: {	        title: {	            text: null	        }	    },
	    series: [{	        name: 'Report',	        data: [2, 3, null, 4, 0, 5, 1, 4, 6, 3]	    }]
	});*/
	
}]);