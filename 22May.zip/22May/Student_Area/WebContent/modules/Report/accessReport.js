﻿angular.module("accessReport", []).controller("accessReportCtrl", ["$scope","$http","config", function ($scope,$http,config) {
	
	$scope.AccessReport = function(){   	
		$http({ 
			method: 'GET', 
			url: config.globalUrl+"lateComingDtls?date=2017-05-09&month=0&year=0", 
			dataType: "json", 
			contentType: "application/json; charset=utf-8" })
        .success(function (data, status) {
            $scope.SchoolList = data;
            $scope.list = $scope.SchoolList;
            $scope.totalItems = $scope.list.length;
            $scope.currentPage = 1;
            $scope.numPerPage = 5;
        })
        .error(function (data, status) {
            sweetAlert("Oops...", "Something went error!", "error");
        });
	};
	
	/*$scope.AccessReport = function(){
		http://10.30.55.109:8080/mining_latest/lateComingDtls?date=2017-05-09&month=0&year=0
		$scope.dataSet = [
		                  
		                  {id:1, student_id:1, student_name:"Rahul", class_name:"LKG-A", card_id: 12345, access_date: 12, readr_start_time: 09.15, reader_end_time: 11.15}, 
		                  {id:2, student_id:1, student_name:"Rahul", class_name:"LKG-A", card_id: 12345, access_date: 12, readr_start_time: 09.15, reader_end_time: 11.15},

		                  {name:"Rahul",index:0},
		                  {name:"Gokul",index:1},
		                  {name:"Ramesh",index:2}
		              ],
		              $scope.current = $scope.dataSet[0],
		              $scope.next = function(){
		                  var i = $scope.getIndex($scope.current.index, 1);
		                  $scope.current = $scope.dataSet[i];
		              },
		              $scope.previous = function(){
		                  var i = $scope.getIndex($scope.current.index, -1);
		                  $scope.current = $scope.dataSet[i];
		              },
		              $scope.getIndex = function(currentIndex, shift){
		                  var len = $scope.dataSet.length;
		                  return (((currentIndex + shift) + len) % len)
		              }
	}*/
	
	// Pagination
    $scope.sort = function (keyname) {
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    }

    $scope.paginate = function (value) {
        var begin, end, index;
        begin = ($scope.currentPage - 1) * $scope.numPerPage;
        end = begin + $scope.numPerPage;
        index = $scope.list.indexOf(value);
        return (begin <= index && index < end);
    };
    // Pagination End
	
	var init = function(){
		$scope.AccessReport();
	};
	init();
	
	
		
}]);