﻿angular.module("weeklyReport", []).controller("weeklyReportCtrl", ["$scope","$http", "config",function ($scope,$http,config) {   	

	
	// GetMonthReport count
	$scope.GetWeeklyReport = function(){
		$http({ 
			method: 'GET', 
			url: config.globalUrl+'weeklyLateComingDtls?count=0', 
			dataType: "json", 
			contentType: "application/json; charset=utf-8" 
		})
        .success(function (data, status) {
            $scope.SchoolList = data;
            $scope.GetWeeklyList = $scope.SchoolList;
            $scope.totalItems = $scope.SchoolList.length;
            $scope.currentPage = 1;
            $scope.numPerPage = 5;
        })
        .error(function (data, status) {
            sweetAlert("Oops...", "Something went error!", "error");
        });
	}
	// GetMonthReport count end
	
	//Pagination
	 $scope.sort = function (keyname) {
	        $scope.sortKey = keyname;   //set the sortKey to the param passed
	        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
	    }

	    $scope.paginate = function (value) {
	        var begin, end, index;
	        begin = ($scope.currentPage - 1) * $scope.numPerPage;
	        end = begin + $scope.numPerPage;
	        index = $scope.GetWeeklyList.indexOf(value);
	        return (begin <= index && index < end);
	    };
	    
	  //Pagination End  
	
	var init = function(){
		$scope.GetWeeklyReport();
	}
	init();
}]);