'use strict';

// declare modules
angular.module('Home', []);
angular.module('dashboard_1', []);
angular.module('tracking', []);

angular.module('accessReport', []);
angular.module('weeklyReport', []);
angular.module('monthlyReport', []);
angular.module('annualReport', []);
angular.module('GUIReport',[]);

angular.module('readerMaster', []);
angular.module('addUser', []);
angular.module('alert', []);
angular.module('AddPermission',[]);

angular.module('mainApp', ['Home', 'dashboard_1', 'tracking', 'weeklyReport', 'accessReport', 'monthlyReport', 'annualReport', 'GUIReport', 'readerMaster', 'addUser', 'alert', 'AddPermission', 'ngRoute'])

.config(['$routeProvider', function ($routeProvider) {

    $routeProvider
         .when('/login', {
             templateUrl: '../Login.html'
         })
        /* .when('/home', {
            controller: 'homeCtrl',
            templateUrl: '../../home/views/home.html'
        })*/
        .when('/dashboard_1', {
            templateUrl: '../../Dashboard_1/views/dashboard_1.html'
        })
        .when('/tracking', {
            templateUrl: '../../Tracking/views/tracking.html'
        })        
        .when('/accessReport', {
            templateUrl: '../../Report/views/accessReport.html'
        })
        .when('/weeklyReport', {
            templateUrl: '../../Report/views/weeklyReport.html'
        })
        .when('/monthlyReport', {
            templateUrl: '../../Report/views/monthlyReport.html'
        })
        .when('/annualReport', {
            templateUrl: '../../Report/views/annualReport.html'
        })        
        .when('/GUIReport', {
            templateUrl: '../../Report/views/GUIReport.html'
        }) 
        .when('/configuration', {
            templateUrl: '../../Configuration/views/configuration.html'
        })
        .when('/readerMaster', {
            templateUrl: '../../Configuration/views/ReaderMaster.html'
        })
        .when('/addUser', {
            templateUrl: '../../Configuration/views/AddUser.html'
        })
        .when('/RolePermission', {
            templateUrl: '../../Configuration/views/RolePermission.html'
        })
       /* .when('/readerType', {
            templateUrl: '../../Configuration/views/ReaderType.html'
        })*/
        .when('/alert', {
            templateUrl: '../../Alert/views/alert.html'
        })        
        .otherwise({ redirectTo: '/dashboard_1' });
}])

.constant('config', {
	globalUrl: 'http://10.30.55.109:8080/mining_latest/'
})

$(function(){
    $(".dropdown").hover(            
            function() {
                $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
                $(this).toggleClass('open');
                $('b', this).toggleClass("caret caret-up");                
            },
            function() {
                $('.dropdown-menu', this).stop( true, true ).fadeOut("fast");
                $(this).toggleClass('open');
                $('b', this).toggleClass("caret caret-up");                
            });
    });
    