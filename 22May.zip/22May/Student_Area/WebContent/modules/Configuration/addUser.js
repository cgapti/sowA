angular.module("addUser", ['angular-table', 'ui.bootstrap', 'ngResource'])

.controller("addUserCtrl", ["$rootScope", "$scope", "$http", "$window", "config", function ($rootScope, $scope, $http, $window, config) {
	
	/*$scope.SelectReader = function () {    	
   	$http.get("http://10.30.55.104:8090/mining_latest/fetchAllROLE")
   	    .then(function(response) {
   	    	$scope.userRoles = response.data;
   	    	console.log(response.data[1].rolename);
   	    });
   }*/
   
    
   $scope.getUsersData = function(){		
			
		$http({ method: 'GET', url: config.globalUrl + "fetchAllUSER", dataType: "json", contentType: "application/json; charset=utf-8" })
       .success(function (data, status) {
           $scope.SchoolList = data;
           $scope.list = $scope.SchoolList;
           $scope.totalItems = $scope.SchoolList.length;
           $scope.currentPage = 1;
           $scope.numPerPage = 5;
       })
       .error(function (data, status) {
           sweetAlert("Oops...", "Something went error!", "error");
       });
	}
   
  
   $scope.SaveUser=function(addUser){	   	   	

   	console.log(addUser);
   	 $http({
            url: globalUrl+'addUSER',
            dataType: 'json',
            method: 'POST',
            data: addUser,
            headers: {
                "Content-Type": "application/json"
            }
        }).success(function (response) {
            swal("Successfully updated!!")
        	$scope.getUsersData();
        }).error(function (error) {
            sweetAlert("Oops...", "Something went wrong!", "error");
        });
   } 
   
   var init = function(){
   	//$scope.SelectReader();
   	$scope.getUsersData();
   }
   init();
}]);

